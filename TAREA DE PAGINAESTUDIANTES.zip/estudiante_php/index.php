<!doctype html>
<html lang="en">

<head>
  <title>Estudiantes</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.0-beta1 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
    integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

</head>
<body>
    <h1>Datos del Estudiante</h1>
    <div class="container">
        <form class="d-flex">
            <div class="col">
                <div class="mb-3">
                    <label for="lbl_carne" class="form-label"><b>Carne</b></label>
                    <input type="text" name="txt_carne" id="txt_carne" class="form-control" placeholder="Carne: E001" required>                   
                </div>
                <div class="mb-3">
                <label for="lbl_nombres" class="form-label"><b>Nombres</b></label>
                <input type="text" name="txt_nombres" id="txt_nombres" class="form-control" placeholder="Nombres: Nombre1 Nombre2 " required>    
                </div>
                </div>
                <div class="mb-3">
                <label for="lbl_apellidos" class="form-label"><b>Apellidos</b></label>
                <input type="text" name="txt_apellidos" id="txt_apellidos" class="form-control" placeholder="Apellidos: Apellido1" required>                  
                </div>
            <div class="mb-3">
            <label for="lbl_direccion" class="form-label"><b>Direccion</b></label>
            <input type="text" name="txt_direccion" id="txt_direccion" class="form-control" placeholder="Direccion: #casa calle avenida lugar" required>                  
            </div>
            <div class="mb-3">
            <label for="lbl_telefono" class="form-label"><b>Telefono</b></label>
            <input type="number" name="txt_telefono" id="txt_telefono" class="form-control" placeholder="Telefono: 5555" required>                  
            </div>
            <div class="mb-3">
            <label for="lbl_correo" class="form-label"><b>Correo</b></label>
            <input type="text" name="txt_correo" id="txt_correo" class="form-control" placeholder="Correo: a@g.com" required>                  
            </div>
            <div class="mb-3">
              <label for="lbl_tipos_sangre" class="form-label"><b>Tipos_sangre</b></label>
              <select class="form-select" name="o+_tipos_sangre" id="o+_tipos_sangre">
                <option value="0">--- Tipos_sangre ---</option>
                <option value="1">--- B+ ---</option>
                <option value="2">--- O+ ---</option>
                <option value="3">--- A- ---</option>
              </select>
            </div>
            <div class="mb-3">
            <label for="lbl_fn" class="form-label"><b>Fecha Nacimiento</b></label>
            <input type="date" name="txt_fn" id="txt_fn" class="form-control" placeholder="fn: aaa-mm-dd" required>                  
            </div>
            <div class="mb-3">
            
            <input type="submit" name="btn_agregar" id="btn_agregar" class="btn btn-primary" value="Agregar">                  
            </div>
            <div class="mb-3">
            <input type="submit" name="btn_modificar" id="btn_modificar" class="btn btn-light" value="Modificar">                  
            </div>
            <div class="mb-3">
            <input type="submit" name="btn_eliminar" id="btn_eliminar" class="btn btn-danger" value="Eliminar">                  
            </div>

            </div>
        </form>
        <div class="table-responsive">
        <table class="table table-striped table-inverse table-responsive">
                <thead class="thead-inverse">
                    <tr>
                        <th>Carne</th>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Direccion</th>
                        <th>Telefono</th>
                        <th>Correo</th>
                        <th>Tipos_sangre</th>
                        <th>Fecha_Nacimiento</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Carne 1</td>
                            <td>Nombre1 Nombre2</td>
                            <td>Apellido1 Apellido2</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                    <tfoot>
                        
                    </tfoot>
            </table>
        </div>
        
    </div>
  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"
    integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js"
    integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous">
  </script>
</body>

</html>