import mysql from 'mysql'
var conectar = mysql.createConnection({
   host : 'localhost',
   user: 'usr_estudiante',
   password : 'Estudiante@123',
   database : 'db_paginaestudiantes'
});
conectar.connect( function(err){
    if(err){
        console.error('error en la conexion ' + err.stack)
        return;
    }
      console.log('Conexion exitosa ID:' + conectar.threadId);

    });
   export {conectar}